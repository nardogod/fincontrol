"use strict";exports.id=84,exports.ids=[84],exports.modules={6084:(e,o,i)=>{i.d(o,{sendInviteEmail:()=>a});async function a(e){console.log("\uD83D\uDCE7 Email de convite simulado:",{to:e.to,subject:`Convite para participar da conta "${e.accountName}"`,html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Voc\xea foi convidado para uma conta!</h2>
        
        <p>Ol\xe1!</p>
        
        <p><strong>${e.inviterName}</strong> convidou voc\xea para participar da conta <strong>"${e.accountName}"</strong> como <strong>${"owner"===e.role?"Propriet\xe1rio":"Membro"}</strong>.</p>
        
        <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0;">O que voc\xea pode fazer:</h3>
          <ul>
            <li>Visualizar transa\xe7\xf5es da conta</li>
            <li>Adicionar novas transa\xe7\xf5es</li>
            <li>Ver relat\xf3rios e gr\xe1ficos</li>
            <li>Gerenciar categorias</li>
          </ul>
        </div>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${e.inviteLink}" 
             style="background: #10b981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: bold;">
            Aceitar Convite
          </a>
        </div>
        
        <p style="color: #6b7280; font-size: 14px;">
          Se voc\xea n\xe3o quiser participar desta conta, pode simplesmente ignorar este email.
        </p>
        
        <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 30px 0;">
        <p style="color: #9ca3af; font-size: 12px;">
          Este convite foi enviado atrav\xe9s do FinControl. Se voc\xea n\xe3o esperava este convite, pode ignorar este email.
        </p>
      </div>
    `});let o=JSON.parse(localStorage.getItem("email_invites")||"[]"),i=e.inviteLink.split("/").pop();return o.push({id:`email_${Date.now()}`,token:i,to:e.to,accountName:e.accountName,inviterName:e.inviterName,role:e.role,inviteLink:e.inviteLink,status:"pending",createdAt:new Date().toISOString()}),localStorage.setItem("email_invites",JSON.stringify(o)),console.log("\uD83D\uDCBE Convite salvo no localStorage:",{token:i,accountName:e.accountName,to:e.to}),{success:!0,message:"Email enviado com sucesso!"}}}};