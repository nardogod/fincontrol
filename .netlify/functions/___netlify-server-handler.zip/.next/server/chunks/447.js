"use strict";exports.id=447,exports.ids=[447],exports.modules={23447:(e,a,t)=>{t.d(a,{formatConfirmationMessage:()=>i,generateHelpMessage:()=>c,parseNaturalLanguage:()=>s});let r={mercado:["mercado","supermercado","compras","feira"],alimentação:["alimenta\xe7\xe3o","alimentacao","comida","restaurante","lanche","caf\xe9","cafe"],transporte:["transporte","uber","taxi","gasolina","combust\xedvel","combustivel"],utilidades:["luz","\xe1gua","agua","internet","telefone","conta","contas","fatura"],lazer:["lazer","cinema","bar","show","evento"],saúde:["sa\xfade","saude","farmacia","farmacia","m\xe9dico","medico","hospital"],salário:["sal\xe1rio","salario","salario"],freelance:["freelance","freela","trabalho extra"],investimento:["investimento","renda","dividendos"],outros:["outros","diversos","geral"]},n=["gastei","gasto","gastar","paguei","pague","pagar","comprei","comprar","sa\xedda","saida","despesa","fatura","conta","contas"],o=["recebi","receba","receber","entrada","ganhei","ganhar","sal\xe1rio","salario","freelance","freela","investimento"];function s(e,a){let t=e.trim();if(t.toLowerCase(),t.startsWith("/"))return{type:null,amount:null,category:null,account:null,description:t,confidence:0,missingFields:["type","amount"]};let{amount:s,currency:i,remainingText:c}=function(e){for(let a of[/(\d+(?:[.,]\d+)?)\s*(?:sek|kr|reais?|brl|r\$\s*)?/i,/(?:r\$\s*|sek\s*|kr\s*)?(\d+(?:[.,]\d+)?)/i]){let t=e.match(a);if(t){let r=parseFloat(t[1].replace(",","."));if(!isNaN(r)&&r>0){let t=e.match(/(?:sek|kr|reais?|brl|r\$)/i);return{amount:r,currency:t?t[0].toLowerCase().includes("sek")||t[0].toLowerCase().includes("kr")?"kr":"brl":void 0,remainingText:e.replace(a,"").trim()}}}}return{amount:null,remainingText:e}}(t),l=function(e){let a=e.toLowerCase();for(let e of o)if(RegExp(`\\b${e}\\b|^${e}\\s+`,"i").test(a))return"income";for(let e of n)if(RegExp(`\\b${e}\\b|^${e}\\s+`,"i").test(a))return"expense";return null}(t),u=l?function(e,a){let t=e.toLowerCase();for(let[e,a]of Object.entries(r))for(let r of a)if(t.includes(r))return e;return null}(t,0):null,m=function(e,a){let t=e.toLowerCase();for(let e of[/(?:da\s+conta|conta|na\s+conta)\s+(\w+(?:\s+\w+)?)/i,/(\w+(?:\s+\w+)?)\s+(?:conta|da\s+conta)$/i]){let r=t.match(e);if(r){let e=r[1].toLowerCase().trim(),t=a.find(a=>{let t=a.name.toLowerCase();return t.includes(e)||e.includes(t)||t===e});if(t)return t}}for(let e of a){let a=e.name.toLowerCase();if(a.split(/\s+/).every(e=>e.length>2&&t.includes(e))||t.includes(a))return e}return null}(t,a.accounts),p=function(e,a,t,s){let i=e.trim();for(let e of(a&&(i=i.replace(RegExp("\\d+(?:[.,]\\d+)?\\s*(?:sek|kr|reais?|brl|r\\$)?","gi"),"").trim()),[...n,...o])){let a=RegExp(`^${e}\\s+`,"gi");i=i.replace(a,"").trim()}if(i=i.replace(/(?:da\s+conta|conta|na\s+conta)\s+\w+(?:\s+\w+)?/gi,"").trim(),s)for(let e of s.toLowerCase().split(/\s+/))e.length>2&&(i=i.replace(RegExp(`\\b${e}\\b`,"gi"),"").trim());if(t)for(let e of r[t]||[])i=i.replace(RegExp(`\\b${e}\\b`,"gi"),"").trim();return(i=(i=i.replace(/\s+/g," ").trim()).replace(/^[,\s]+|[,\s]+$/g,"").trim())&&i.length>1?i:t?t.charAt(0).toUpperCase()+t.slice(1):"Transa\xe7\xe3o"}(t,s,u,m?.name||null),d=0,f=[];return s&&s>0?d+=.4:f.push("amount"),l?d+=.3:f.push("type"),u?d+=.2:l&&f.push("category"),m?d+=.1:a.accounts.length>1&&f.push("account"),{type:l,amount:s,currency:i,category:u,account:m?.name||null,description:p,confidence:d,missingFields:f}}function i(e,a){let t="expense"===e.type?"despesa":"income"===e.type?"receita":"transa\xe7\xe3o",r=e.amount?`${e.amount.toFixed(2).replace(".",",")} ${"kr"===e.currency?"kr":"R$"}`:"[valor n\xe3o identificado]",n=e.category||"Outros",o=e.account||"[conta n\xe3o especificada]";return`✅ Ok, devo registrar ${t} de ${r} na categoria "${n}" na conta "${o}"?`}function c(e){let a=e.accounts.map(e=>`• ${e.name}`).join("\n"),t=e.categories.filter(e=>"expense"===e.type).map(e=>`• ${e.name}`).join("\n"),r=e.categories.filter(e=>"income"===e.type).map(e=>`• ${e.name}`).join("\n");return`❓ *N\xe3o entendi sua mensagem*

*Como usar:*
Envie sua transa\xe7\xe3o de forma simples:

*Exemplos de despesas:*
• "gastei 15 sek da conta casa no mercado"
• "gasto 15 mercado conta pessoal"
• "Gasto caf\xe9 98 da conta pessoal"
• "Gasto internet 125 da conta pessoal"

*Exemplos de receitas:*
• "receita 5000 salario conta principal"
• "recebi 200 freelance conta pessoal"

*Suas contas dispon\xedveis:*
${a||"Nenhuma conta encontrada"}

*Categorias de despesa:*
${t||"Nenhuma categoria encontrada"}

*Categorias de receita:*
${r||"Nenhuma categoria encontrada"}

💡 *Dica:* Se n\xe3o especificar a conta e tiver v\xe1rias, eu vou perguntar qual usar.`}}};